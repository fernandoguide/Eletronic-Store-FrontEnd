import {combineReducers} from 'redux';


import Login from './Login';


export default combineReducers({

    Login,

});